

<?php $__env->startSection('title', 'Job Applications'); ?>

<?php $__env->startSection('content'); ?>
    <div class="mb-4">
        <h1>Applications for: <?php echo e($job->title); ?></h1>
        <p class="text-muted">Posted on <?php echo e($job->created_at->format('M d, Y')); ?></p>
    </div>
    
    <?php $__empty_1 = true; $__currentLoopData = $applications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $application): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="card mb-4">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="mb-0"><?php echo e($application->candidate->name); ?></h5>
                <span class="badge <?php echo e($application->status == 'pending' ? 'bg-warning text-dark' : ($application->status == 'accepted' ? 'bg-success' : ($application->status == 'rejected' ? 'bg-danger' : 'bg-info'))); ?>">
                    <?php echo e(ucfirst($application->status)); ?>

                </span>
            </div>
            <div class="card-body">
                <h6 class="card-subtitle mb-2 text-muted">Applied on <?php echo e($application->created_at->format('M d, Y')); ?></h6>
                
                <?php if($application->candidate->resume): ?>
                    <p><a href="<?php echo e(asset('storage/resumes/' . $application->candidate->resume)); ?>" target="_blank" class="btn btn-sm btn-outline-primary">View Resume</a></p>
                <?php else: ?>
                    <p class="text-muted">No resume uploaded</p>
                <?php endif; ?>
                
                <h6>Cover Letter:</h6>
                <p class="card-text"><?php echo e($application->cover_letter); ?></p>
                
                <form method="POST" action="<?php echo e(route('applications.status.update', $application->id)); ?>" class="mt-3">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class="row g-3 align-items-center">
                        <div class="col-auto">
                            <label for="status" class="col-form-label">Update Status:</label>
                        </div>
                        <div class="col-auto">
                            <select class="form-select" id="status" name="status">
                                <option value="pending" <?php echo e($application->status == 'pending' ? 'selected' : ''); ?>>Pending</option>
                                <option value="reviewed" <?php echo e($application->status == 'reviewed' ? 'selected' : ''); ?>>Reviewed</option>
                                <option value="accepted" <?php echo e($application->status == 'accepted' ? 'selected' : ''); ?>>Accepted</option>
                                <option value="rejected" <?php echo e($application->status == 'rejected' ? 'selected' : ''); ?>>Rejected</option>
                            </select>
                        </div>
                        <div class="col-auto">
                            <button type="submit" class="btn btn-primary">Update</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="alert alert-info">
            No applications received yet.
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\job-portal\resources\views/employer/applications.blade.php ENDPATH**/ ?>