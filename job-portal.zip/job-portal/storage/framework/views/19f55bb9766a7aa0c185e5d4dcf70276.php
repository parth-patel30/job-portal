

<?php $__env->startSection('title', 'All Jobs'); ?>

<?php $__env->startSection('content'); ?>
    <h2>Available Jobs</h2>
    
    <?php if($jobs->count() > 0): ?>
        <div class="row">
            <?php $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-6 mb-4">
                    <div class="card h-100">
                        <div class="card-body">
                            <h5 class="card-title"><?php echo e($job->title); ?></h5>
                            <h6 class="card-subtitle mb-2 text-muted"><?php echo e($job->employer->company_name); ?></h6>
                            <p class="card-text">
                                <strong>Location:</strong> <?php echo e($job->location); ?><br>
                                <strong>Type:</strong> <?php echo e($job->type); ?><br>
                                <?php if($job->salary): ?>
                                    <strong>Salary:</strong> $<?php echo e(number_format($job->salary, 2)); ?>

                                <?php endif; ?>
                            </p>
                            <a href="<?php echo e(route('jobs.show', $job->id)); ?>" class="btn btn-primary">View Details</a>
                        </div>
                        <div class="card-footer text-muted">
                            Posted <?php echo e($job->created_at->diffForHumans()); ?>

                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        
        <div class="d-flex justify-content-center mt-4">
            <?php echo e($jobs->links()); ?>

        </div>
    <?php else: ?>
        <div class="alert alert-info">
            No jobs available at the moment.
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\job-portal\resources\views/jobs/index.blade.php ENDPATH**/ ?>