

<?php $__env->startSection('title', 'Employer Dashboard'); ?>

<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2>My Job Listings</h2>
        <a href="<?php echo e(route('jobs.create')); ?>" class="btn btn-primary">Post New Job</a>
    </div>
    
    <?php if($jobs->count() > 0): ?>
        <div class="table-responsive">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Title</th>
                        <th>Location</th>
                        <th>Applications</th>
                        <th>Status</th>
                        <th>Posted</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($job->title); ?></td>
                            <td><?php echo e($job->location); ?></td>
                            <td>
                                <a href="<?php echo e(route('jobs.applications', $job->id)); ?>">
                                    <?php echo e($job->applications->count()); ?> application(s)
                                </a>
                            </td>
                            <td>
                                <?php if(!$job->is_approved): ?>
                                    <span class="badge bg-warning text-dark">Pending Approval</span>
                                <?php elseif($job->is_active): ?>
                                    <span class="badge bg-success">Active</span>
                                <?php else: ?>
                                    <span class="badge bg-secondary">Inactive</span>
                                <?php endif; ?>
                            </td>
                            <td><?php echo e($job->created_at->format('M d, Y')); ?></td>
                            <td>
                                <a href="<?php echo e(route('jobs.show', $job->id)); ?>" class="btn btn-sm btn-info">View</a>
                                <a href="<?php echo e(route('jobs.edit', $job->id)); ?>" class="btn btn-sm btn-warning">Edit</a>
                                <form action="<?php echo e(route('jobs.destroy', $job->id)); ?>" method="POST" class="d-inline" onsubmit="return confirm('Are you sure you want to delete this job posting?');">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-sm btn-danger">Delete</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        
        <div class="d-flex justify-content-center mt-4">
            <?php echo e($jobs->links()); ?>

        </div>
    <?php else: ?>
        <div class="alert alert-info">
            You haven't posted any jobs yet. <a href="<?php echo e(route('jobs.create')); ?>">Create your first job posting</a>.
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\job-portal\resources\views/employer/dashboard.blade.php ENDPATH**/ ?>