

<?php $__env->startSection('title', 'Candidate Dashboard'); ?>

<?php $__env->startSection('content'); ?>
    <div class="mb-4">
        <h1>Your Job Applications</h1>
    </div>
    
    <?php $__empty_1 = true; $__currentLoopData = $applications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $application): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="card mb-4">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="mb-0"><?php echo e($application->jobPost->title); ?></h5>
                <span class="badge <?php echo e($application->status == 'pending' ? 'bg-warning text-dark' : ($application->status == 'accepted' ? 'bg-success' : ($application->status == 'rejected' ? 'bg-danger' : 'bg-info'))); ?>">
                    <?php echo e(ucfirst($application->status)); ?>

                </span>
            </div>
            <div class="card-body">
                <h6 class="card-subtitle mb-2 text-muted"><?php echo e($application->jobPost->employer->company_name); ?> - <?php echo e($application->jobPost->location); ?></h6>
                <p class="text-muted">Applied on <?php echo e($application->created_at->format('M d, Y')); ?></p>
                
                <h6>Cover Letter:</h6>
                <p class="card-text"><?php echo e($application->cover_letter); ?></p>
                
                <a href="<?php echo e(route('jobs.show', $application->jobPost->id)); ?>" class="btn btn-outline-primary">View Job Details</a>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="alert alert-info">
            You haven't applied to any jobs yet. <a href="<?php echo e(route('jobs.index')); ?>">Browse available jobs</a>
        </div>
    <?php endif; ?>

    <div class="d-flex justify-content-center mt-4">
        <?php echo e($applications->links()); ?>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\job-portal\resources\views/candidate/dashboard.blade.php ENDPATH**/ ?>