

<?php $__env->startSection('title', 'Home'); ?>

<?php $__env->startSection('content'); ?>
    <div class="jumbotron bg-light p-5 rounded mb-4">
        <h1>Find Your Dream Job</h1>
        <p class="lead">Browse through hundreds of job listings or post your own job.</p>
        <hr class="my-4">
        <p>Join our community of employers and job seekers today.</p>
        <?php if(auth()->guard()->guest()): ?>
            <a class="btn btn-primary btn-lg" href="<?php echo e(route('register')); ?>" role="button">Get Started</a>
        <?php else: ?>
            <a class="btn btn-primary btn-lg" href="<?php echo e(route('jobs.index')); ?>" role="button">Browse Jobs</a>
        <?php endif; ?>
    </div>
    
    <h3 class="mb-4">Latest Job Opportunities</h3>
    
    <?php if($jobs->count() > 0): ?>
        <div class="row">
            <?php $__currentLoopData = $jobs->take(6); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4 mb-4">
                    <div class="card h-100">
                        <div class="card-body">
                            <h5 class="card-title"><?php echo e($job->title); ?></h5>
                            <h6 class="card-subtitle mb-2 text-muted"><?php echo e($job->employer->company_name); ?></h6>
                            <p class="card-text">
                                <strong>Location:</strong> <?php echo e($job->location); ?><br>
                                <strong>Type:</strong> <?php echo e($job->type); ?>

                            </p>
                            <a href="<?php echo e(route('jobs.show', $job->id)); ?>" class="btn btn-sm btn-outline-primary">View Details</a>
                        </div>
                        <div class="card-footer text-muted">
                            Posted <?php echo e($job->created_at->diffForHumans()); ?>

                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        
        <div class="text-center mt-4">
            <a href="<?php echo e(route('jobs.index')); ?>" class="btn btn-primary">View All Jobs</a>
        </div>
    <?php else: ?>
        <div class="alert alert-info">
            No jobs available at the moment.
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\job-portal\resources\views/home.blade.php ENDPATH**/ ?>