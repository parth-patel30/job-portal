

<?php $__env->startSection('title', 'Job Approvals'); ?>

<?php $__env->startSection('content'); ?>
    <h2>Job Posts Pending Approval</h2>
    
    <?php if($jobs->count() > 0): ?>
        <div class="table-responsive mt-4">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Title</th>
                        <th>Company</th>
                        <th>Location</th>
                        <th>Type</th>
                        <th>Posted</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($job->title); ?></td>
                            <td><?php echo e($job->employer->company_name); ?></td>
                            <td><?php echo e($job->location); ?></td>
                            <td><?php echo e($job->type); ?></td>
                            <td><?php echo e($job->created_at->format('M d, Y')); ?></td>
                            <td>
                                <form action="<?php echo e(route('admin.jobs.approve', $job->id)); ?>" method="POST" class="d-inline">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="btn btn-sm btn-success">Approve</button>
                                </form>
                                <a href="<?php echo e(route('jobs.show', $job->id)); ?>" class="btn btn-sm btn-info">View</a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        
        <div class="d-flex justify-content-center mt-4">
            <?php echo e($jobs->links()); ?>

        </div>
    <?php else: ?>
        <div class="alert alert-info mt-4">
            No jobs pending approval at the moment.
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\job-portal\resources\views/admin/jobs-approval.blade.php ENDPATH**/ ?>