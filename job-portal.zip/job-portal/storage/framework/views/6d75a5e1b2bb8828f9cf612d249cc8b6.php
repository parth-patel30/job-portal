

<?php $__env->startSection('title', 'Admin Dashboard'); ?>

<?php $__env->startSection('content'); ?>
    <h2>Admin Dashboard</h2>
    
    <div class="row mt-4">
        <div class="col-md-3 mb-4">
            <div class="card text-white bg-primary">
                <div class="card-body">
                    <h5 class="card-title">Employers</h5>
                    <p class="card-text display-4"><?php echo e($employersCount); ?></p>
                </div>
            </div>
        </div>
        <div class="col-md-3 mb-4">
            <div class="card text-white bg-success">
                <div class="card-body">
                    <h5 class="card-title">Job Seekers</h5>
                    <p class="card-text display-4"><?php echo e($candidatesCount); ?></p>
                </div>
            </div>
        </div>
        <div class="col-md-3 mb-4">
            <div class="card text-white bg-info">
                <div class="card-body">
                    <h5 class="card-title">Job Posts</h5>
                    <p class="card-text display-4"><?php echo e($jobPostsCount); ?></p>
                </div>
            </div>
        </div>
        <div class="col-md-3 mb-4">
            <div class="card text-white bg-warning">
                <div class="card-body">
                    <h5 class="card-title">Pending Approvals</h5>
                    <p class="card-text display-4"><?php echo e($pendingApprovalCount); ?></p>
                </div>
            </div>
        </div>
    </div>
    
    <div class="card mt-4">
        <div class="card-header">
            <h4>Quick Actions</h4>
        </div>
        <div class="card-body">
            <div class="d-grid gap-2 d-md-flex">
                <a href="<?php echo e(route('admin.jobs.approval')); ?>" class="btn btn-primary">
                    Review Pending Jobs
                </a>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\job-portal\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>