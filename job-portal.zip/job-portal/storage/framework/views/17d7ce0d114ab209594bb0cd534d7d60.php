

<?php $__env->startSection('title', $job->title); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header">
            <h3><?php echo e($job->title); ?></h3>
            <h6 class="text-muted"><?php echo e($job->employer->company_name); ?></h6>
        </div>
        <div class="card-body">
            <div class="row mb-3">
                <div class="col-md-4">
                    <strong>Location:</strong> <?php echo e($job->location); ?>

                </div>
                <div class="col-md-4">
                    <strong>Job Type:</strong> <?php echo e($job->type); ?>

                </div>
                <div class="col-md-4">
                    <?php if($job->salary): ?>
                        <strong>Salary:</strong> $<?php echo e(number_format($job->salary, 2)); ?>

                    <?php endif; ?>
                </div>
            </div>
            
            <div class="mb-4">
                <h5>Job Description</h5>
                <div class="job-description">
                    <?php echo e($job->description); ?>

                </div>
            </div>
            
            <?php if(auth()->guard()->check()): ?>
                <?php if(auth()->user()->hasRole('Candidate')): ?>
                    <div class="mt-4">
                        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#applyModal">
                            Apply for this Job
                        </button>
                    </div>
                    
                    <!-- Apply Modal -->
                    <div class="modal fade" id="applyModal" tabindex="-1" aria-labelledby="applyModalLabel" aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <form action="<?php echo e(route('jobs.apply', $job->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="applyModalLabel">Apply for <?php echo e($job->title); ?></h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body">
                                        <div class="mb-3">
                                            <label for="cover_letter" class="form-label">Cover Letter</label>
                                            <textarea class="form-control" id="cover_letter" name="cover_letter" rows="5" required></textarea>
                                            <div class="form-text">Explain why you're a good fit for this position.</div>
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                        <button type="submit" class="btn btn-primary">Submit Application</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            <?php else: ?>
                <div class="alert alert-info mt-4">
                    Please <a href="<?php echo e(route('login')); ?>">login</a> to apply for this job.
                </div>
            <?php endif; ?>
        </div>
        <div class="card-footer text-muted">
            Posted <?php echo e($job->created_at->diffForHumans()); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\job-portal\resources\views/jobs/show.blade.php ENDPATH**/ ?>