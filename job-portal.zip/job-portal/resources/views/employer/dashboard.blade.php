@extends('layouts.app')

@section('title', 'Employer Dashboard')

@section('content')
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2>My Job Listings</h2>
        <a href="{{ route('jobs.create') }}" class="btn btn-primary">Post New Job</a>
    </div>
    
    @if($jobs->count() > 0)
        <div class="table-responsive">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Title</th>
                        <th>Location</th>
                        <th>Applications</th>
                        <th>Status</th>
                        <th>Posted</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($jobs as $job)
                        <tr>
                            <td>{{ $job->title }}</td>
                            <td>{{ $job->location }}</td>
                            <td>
                                <a href="{{ route('jobs.applications', $job->id) }}">
                                    {{ $job->applications->count() }} application(s)
                                </a>
                            </td>
                            <td>
                                @if(!$job->is_approved)
                                    <span class="badge bg-warning text-dark">Pending Approval</span>
                                @elseif($job->is_active)
                                    <span class="badge bg-success">Active</span>
                                @else
                                    <span class="badge bg-secondary">Inactive</span>
                                @endif
                            </td>
                            <td>{{ $job->created_at->format('M d, Y') }}</td>
                            <td>
                                <a href="{{ route('jobs.show', $job->id) }}" class="btn btn-sm btn-info">View</a>
                                <a href="{{ route('jobs.edit', $job->id) }}" class="btn btn-sm btn-warning">Edit</a>
                                <form action="{{ route('jobs.destroy', $job->id) }}" method="POST" class="d-inline" onsubmit="return confirm('Are you sure you want to delete this job posting?');">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="btn btn-sm btn-danger">Delete</button>
                                </form>
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
        
        <div class="d-flex justify-content-center mt-4">
            {{ $jobs->links() }}
        </div>
    @else
        <div class="alert alert-info">
            You haven't posted any jobs yet. <a href="{{ route('jobs.create') }}">Create your first job posting</a>.
        </div>
    @endif
@endsection