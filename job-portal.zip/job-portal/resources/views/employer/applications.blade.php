@extends('layouts.app')

@section('title', 'Job Applications')

@section('content')
    <div class="mb-4">
        <h1>Applications for: {{ $job->title }}</h1>
        <p class="text-muted">Posted on {{ $job->created_at->format('M d, Y') }}</p>
    </div>
    
    @forelse($applications as $application)
        <div class="card mb-4">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="mb-0">{{ $application->candidate->name }}</h5>
                <span class="badge {{ $application->status == 'pending' ? 'bg-warning text-dark' : ($application->status == 'accepted' ? 'bg-success' : ($application->status == 'rejected' ? 'bg-danger' : 'bg-info')) }}">
                    {{ ucfirst($application->status) }}
                </span>
            </div>
            <div class="card-body">
                <h6 class="card-subtitle mb-2 text-muted">Applied on {{ $application->created_at->format('M d, Y') }}</h6>
                
                @if($application->candidate->resume)
                    <p><a href="{{ asset('storage/resumes/' . $application->candidate->resume) }}" target="_blank" class="btn btn-sm btn-outline-primary">View Resume</a></p>
                @else
                    <p class="text-muted">No resume uploaded</p>
                @endif
                
                <h6>Cover Letter:</h6>
                <p class="card-text">{{ $application->cover_letter }}</p>
                
                <form method="POST" action="{{ route('applications.status.update', $application->id) }}" class="mt-3">
                    @csrf
                    @method('PUT')
                    <div class="row g-3 align-items-center">
                        <div class="col-auto">
                            <label for="status" class="col-form-label">Update Status:</label>
                        </div>
                        <div class="col-auto">
                            <select class="form-select" id="status" name="status">
                                <option value="pending" {{ $application->status == 'pending' ? 'selected' : '' }}>Pending</option>
                                <option value="reviewed" {{ $application->status == 'reviewed' ? 'selected' : '' }}>Reviewed</option>
                                <option value="accepted" {{ $application->status == 'accepted' ? 'selected' : '' }}>Accepted</option>
                                <option value="rejected" {{ $application->status == 'rejected' ? 'selected' : '' }}>Rejected</option>
                            </select>
                        </div>
                        <div class="col-auto">
                            <button type="submit" class="btn btn-primary">Update</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    @empty
        <div class="alert alert-info">
            No applications received yet.
        </div>
    @endforelse
@endsection