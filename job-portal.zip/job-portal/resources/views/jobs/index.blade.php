@extends('layouts.app')

@section('title', 'All Jobs')

@section('content')
    <h2>Available Jobs</h2>
    
    @if($jobs->count() > 0)
        <div class="row">
            @foreach($jobs as $job)
                <div class="col-md-6 mb-4">
                    <div class="card h-100">
                        <div class="card-body">
                            <h5 class="card-title">{{ $job->title }}</h5>
                            <h6 class="card-subtitle mb-2 text-muted">{{ $job->employer->company_name }}</h6>
                            <p class="card-text">
                                <strong>Location:</strong> {{ $job->location }}<br>
                                <strong>Type:</strong> {{ $job->type }}<br>
                                @if($job->salary)
                                    <strong>Salary:</strong> ${{ number_format($job->salary, 2) }}
                                @endif
                            </p>
                            <a href="{{ route('jobs.show', $job->id) }}" class="btn btn-primary">View Details</a>
                        </div>
                        <div class="card-footer text-muted">
                            Posted {{ $job->created_at->diffForHumans() }}
                        </div>
                    </div>
                </div>
            @endforeach
        </div>
        
        <div class="d-flex justify-content-center mt-4">
            {{ $jobs->links() }}
        </div>
    @else
        <div class="alert alert-info">
            No jobs available at the moment.
        </div>
    @endif
@endsection