@extends('layouts.app')

@section('title', $job->title)

@section('content')
    <div class="card">
        <div class="card-header">
            <h3>{{ $job->title }}</h3>
            <h6 class="text-muted">{{ $job->employer->company_name }}</h6>
        </div>
        <div class="card-body">
            <div class="row mb-3">
                <div class="col-md-4">
                    <strong>Location:</strong> {{ $job->location }}
                </div>
                <div class="col-md-4">
                    <strong>Job Type:</strong> {{ $job->type }}
                </div>
                <div class="col-md-4">
                    @if($job->salary)
                        <strong>Salary:</strong> ${{ number_format($job->salary, 2) }}
                    @endif
                </div>
            </div>
            
            <div class="mb-4">
                <h5>Job Description</h5>
                <div class="job-description">
                    {{ $job->description }}
                </div>
            </div>
            
            @auth
                @if(auth()->user()->hasRole('Candidate'))
                    <div class="mt-4">
                        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#applyModal">
                            Apply for this Job
                        </button>
                    </div>
                    
                    <!-- Apply Modal -->
                    <div class="modal fade" id="applyModal" tabindex="-1" aria-labelledby="applyModalLabel" aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <form action="{{ route('jobs.apply', $job->id) }}" method="POST">
                                    @csrf
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="applyModalLabel">Apply for {{ $job->title }}</h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body">
                                        <div class="mb-3">
                                            <label for="cover_letter" class="form-label">Cover Letter</label>
                                            <textarea class="form-control" id="cover_letter" name="cover_letter" rows="5" required></textarea>
                                            <div class="form-text">Explain why you're a good fit for this position.</div>
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                        <button type="submit" class="btn btn-primary">Submit Application</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                @endif
            @else
                <div class="alert alert-info mt-4">
                    Please <a href="{{ route('login') }}">login</a> to apply for this job.
                </div>
            @endauth
        </div>
        <div class="card-footer text-muted">
            Posted {{ $job->created_at->diffForHumans() }}
        </div>
    </div>
@endsection