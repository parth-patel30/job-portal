@extends('layouts.app')

@section('title', 'Candidate Profile')

@section('content')
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Candidate Profile</div>
                <div class="card-body">
                    <form method="POST" action="{{ route('candidate.profile.update') }}" enctype="multipart/form-data">
                        @csrf
                        @method('PUT')
                        
                        <div class="mb-3">
                            <label for="name" class="form-label">Name</label>
                            <input type="text" class="form-control @error('name') is-invalid @enderror" id="name" name="name" value="{{ old('name', auth()->user()->name) }}" required>
                            @error('name')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                        
                        <div class="mb-3">
                            <label for="phone" class="form-label">Phone</label>
                            <input type="text" class="form-control @error('phone') is-invalid @enderror" id="phone" name="phone" value="{{ old('phone', auth()->user()->phone) }}">
                            @error('phone')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                        
                        <div class="mb-3">
                            <label for="about" class="form-label">About</label>
                            <textarea class="form-control @error('about') is-invalid @enderror" id="about" name="about" rows="5">{{ old('about', auth()->user()->about) }}</textarea>
                            @error('about')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                        
                        <div class="mb-3">
                            <label for="resume" class="form-label">Resume (PDF, DOC, DOCX)</label>
                            <input type="file" class="form-control @error('resume') is-invalid @enderror" id="resume" name="resume">
                            @error('resume')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                            
                            @if(auth()->user()->resume)
                                <div class="mt-2">
                                    <p>Current Resume: <a href="{{ asset('storage/resumes/' . auth()->user()->resume) }}" target="_blank">{{ auth()->user()->resume }}</a></p>
                                </div>
                            @endif
                        </div>
                        
                        <button type="submit" class="btn btn-primary">Update Profile</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
@endsection