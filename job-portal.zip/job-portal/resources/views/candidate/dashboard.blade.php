@extends('layouts.app')

@section('title', 'Candidate Dashboard')

@section('content')
    <div class="mb-4">
        <h1>Your Job Applications</h1>
    </div>
    
    @forelse($applications as $application)
        <div class="card mb-4">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="mb-0">{{ $application->jobPost->title }}</h5>
                <span class="badge {{ $application->status == 'pending' ? 'bg-warning text-dark' : ($application->status == 'accepted' ? 'bg-success' : ($application->status == 'rejected' ? 'bg-danger' : 'bg-info')) }}">
                    {{ ucfirst($application->status) }}
                </span>
            </div>
            <div class="card-body">
                <h6 class="card-subtitle mb-2 text-muted">{{ $application->jobPost->employer->company_name }} - {{ $application->jobPost->location }}</h6>
                <p class="text-muted">Applied on {{ $application->created_at->format('M d, Y') }}</p>
                
                <h6>Cover Letter:</h6>
                <p class="card-text">{{ $application->cover_letter }}</p>
                
                <a href="{{ route('jobs.show', $application->jobPost->id) }}" class="btn btn-outline-primary">View Job Details</a>
            </div>
        </div>
    @empty
        <div class="alert alert-info">
            You haven't applied to any jobs yet. <a href="{{ route('jobs.index') }}">Browse available jobs</a>
        </div>
    @endforelse

    <div class="d-flex justify-content-center mt-4">
        {{ $applications->links() }}
    </div>
@endsection