@extends('layouts.app')

@section('title', 'Job Approvals')

@section('content')
    <h2>Job Posts Pending Approval</h2>
    
    @if($jobs->count() > 0)
        <div class="table-responsive mt-4">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Title</th>
                        <th>Company</th>
                        <th>Location</th>
                        <th>Type</th>
                        <th>Posted</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($jobs as $job)
                        <tr>
                            <td>{{ $job->title }}</td>
                            <td>{{ $job->employer->company_name }}</td>
                            <td>{{ $job->location }}</td>
                            <td>{{ $job->type }}</td>
                            <td>{{ $job->created_at->format('M d, Y') }}</td>
                            <td>
                                <form action="{{ route('admin.jobs.approve', $job->id) }}" method="POST" class="d-inline">
                                    @csrf
                                    <button type="submit" class="btn btn-sm btn-success">Approve</button>
                                </form>
                                <a href="{{ route('jobs.show', $job->id) }}" class="btn btn-sm btn-info">View</a>
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
        
        <div class="d-flex justify-content-center mt-4">
            {{ $jobs->links() }}
        </div>
    @else
        <div class="alert alert-info mt-4">
            No jobs pending approval at the moment.
        </div>
    @endif
@endsection