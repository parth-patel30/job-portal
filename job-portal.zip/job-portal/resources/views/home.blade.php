@extends('layouts.app')

@section('title', 'Home')

@section('content')
    <div class="jumbotron bg-light p-5 rounded mb-4">
        <h1>Find Your Dream Job</h1>
        <p class="lead">Browse through hundreds of job listings or post your own job.</p>
        <hr class="my-4">
        <p>Join our community of employers and job seekers today.</p>
        @guest
            <a class="btn btn-primary btn-lg" href="{{ route('register') }}" role="button">Get Started</a>
        @else
            <a class="btn btn-primary btn-lg" href="{{ route('jobs.index') }}" role="button">Browse Jobs</a>
        @endguest
    </div>
    
    <h3 class="mb-4">Latest Job Opportunities</h3>
    
    @if($jobs->count() > 0)
        <div class="row">
            @foreach($jobs->take(6) as $job)
                <div class="col-md-4 mb-4">
                    <div class="card h-100">
                        <div class="card-body">
                            <h5 class="card-title">{{ $job->title }}</h5>
                            <h6 class="card-subtitle mb-2 text-muted">{{ $job->employer->company_name }}</h6>
                            <p class="card-text">
                                <strong>Location:</strong> {{ $job->location }}<br>
                                <strong>Type:</strong> {{ $job->type }}
                            </p>
                            <a href="{{ route('jobs.show', $job->id) }}" class="btn btn-sm btn-outline-primary">View Details</a>
                        </div>
                        <div class="card-footer text-muted">
                            Posted {{ $job->created_at->diffForHumans() }}
                        </div>
                    </div>
                </div>
            @endforeach
        </div>
        
        <div class="text-center mt-4">
            <a href="{{ route('jobs.index') }}" class="btn btn-primary">View All Jobs</a>
        </div>
    @else
        <div class="alert alert-info">
            No jobs available at the moment.
        </div>
    @endif
@endsection