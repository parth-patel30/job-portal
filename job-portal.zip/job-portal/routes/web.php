<?php

use App\Http\Controllers\AdminController;
use App\Http\Controllers\Auth\LoginController;
use App\Http\Controllers\Auth\RegisterController;
use App\Http\Controllers\CandidateController;
use App\Http\Controllers\EmployerController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\JobApplicationController;
use App\Http\Controllers\JobPostController;
use Illuminate\Support\Facades\Route;

// Public routes
Route::get('/', [HomeController::class, 'index'])->name('home');

// Authentication routes
Route::get('/login', [LoginController::class, 'showLoginForm'])->name('login');
Route::post('/login', [LoginController::class, 'login']);
Route::post('/logout', [LoginController::class, 'logout'])->name('logout');
Route::get('/register', [RegisterController::class, 'showRegistrationForm'])->name('register');
Route::post('/register', [RegisterController::class, 'register']);

// Job listing routes
Route::get('/jobs', [JobPostController::class, 'index'])->name('jobs.index');
Route::get('/jobs/{id}', [JobPostController::class, 'show'])->name('jobs.show');

// Protected routes
Route::middleware(['auth'])->group(function () {
    // Admin routes
    Route::middleware(['role:Admin'])->prefix('admin')->group(function () {
        Route::get('/dashboard', [AdminController::class, 'dashboard'])->name('admin.dashboard');
        Route::get('/jobs/approval', [AdminController::class, 'jobsForApproval'])->name('admin.jobs.approval');
        Route::post('/jobs/{id}/approve', [AdminController::class, 'approveJob'])->name('admin.jobs.approve');
    });

    // Employer routes
    Route::middleware(['role:Employer'])->prefix('employer')->group(function () {
        Route::get('/dashboard', [EmployerController::class, 'dashboard'])->name('employer.dashboard');
        Route::get('/profile', [EmployerController::class, 'profile'])->name('employer.profile');
        Route::put('/profile', [EmployerController::class, 'updateProfile'])->name('employer.profile.update');
        Route::get('/jobs/create', [JobPostController::class, 'create'])->name('jobs.create');
        Route::post('/jobs', [JobPostController::class, 'store'])->name('jobs.store');
        Route::get('/jobs/{id}/edit', [JobPostController::class, 'edit'])->name('jobs.edit');
        Route::put('/jobs/{id}', [JobPostController::class, 'update'])->name('jobs.update');
        Route::delete('/jobs/{id}', [JobPostController::class, 'destroy'])->name('jobs.destroy');
        Route::get('/jobs/{id}/applications', [JobApplicationController::class, 'applications'])->name('jobs.applications');
        Route::put('/applications/{id}/status', [JobApplicationController::class, 'updateStatus'])->name('applications.status.update');
    });

    // Candidate routes
    Route::middleware(['role:Candidate'])->prefix('candidate')->group(function () {
        Route::get('/dashboard', [CandidateController::class, 'dashboard'])->name('candidate.dashboard');
        Route::get('/profile', [CandidateController::class, 'profile'])->name('candidate.profile');
        Route::put('/profile', [CandidateController::class, 'updateProfile'])->name('candidate.profile.update');
        Route::post('/jobs/{id}/apply', [JobApplicationController::class, 'apply'])->name('jobs.apply');
    });
});