<?php

namespace App\Http\Controllers;

use App\Models\JobPost;
use Illuminate\Http\Request;

class HomeController extends Controller
{
    public function index()
    {
        $jobs = JobPost::where('is_active', true)
                      ->where('is_approved', true)
                      ->latest()
                      ->paginate(10);
        
        return view('home', compact('jobs'));
    }
}