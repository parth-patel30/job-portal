<?php

namespace App\Http\Controllers;

use App\Models\JobApplication;
use App\Models\JobPost;
use Illuminate\Http\Request;

class JobApplicationController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function apply(Request $request, $jobId)
    {
        $this->middleware('role:Candidate');
        
        $job = JobPost::where('is_active', true)
                     ->where('is_approved', true)
                     ->findOrFail($jobId);
        
        // Check if already applied
        $existingApplication = JobApplication::where('job_post_id', $job->id)
                                           ->where('candidate_id', auth()->id())
                                           ->first();
        
        if ($existingApplication) {
            return redirect()->back()->with('error', 'You have already applied for this job');
        }
        
        $validated = $request->validate([
            'cover_letter' => 'required|string',
        ]);
        
        JobApplication::create([
            'job_post_id' => $job->id,
            'candidate_id' => auth()->id(),
            'cover_letter' => $validated['cover_letter'],
            'status' => 'pending',
        ]);
        
        return redirect()->route('candidate.dashboard')->with('success', 'Application submitted successfully');
    }

    public function applications($jobId)
    {
        $this->middleware('role:Employer');
        
        $job = auth()->user()->jobPosts()->findOrFail($jobId);
        $applications = $job->applications()->with('candidate')->get();
        
        return view('employer.applications', compact('job', 'applications'));
    }

    public function updateStatus(Request $request, $applicationId)
    {
        $this->middleware('role:Employer');
        
        $validated = $request->validate([
            'status' => 'required|in:pending,reviewed,accepted,rejected',
        ]);
        
        $application = JobApplication::findOrFail($applicationId);
        
        // Check if the employer owns the job post
        if ($application->jobPost->employer_id != auth()->id()) {
            abort(403, 'Unauthorized action.');
        }
        
        $application->status = $validated['status'];
        $application->save();
        
        return redirect()->back()->with('success', 'Application status updated successfully');
    }
}