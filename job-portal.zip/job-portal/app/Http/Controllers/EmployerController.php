<?php

namespace App\Http\Controllers;

use App\Models\JobPost;
use Illuminate\Http\Request;

class EmployerController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
        $this->middleware('role:Employer');
    }

    public function dashboard()
    {
        $jobs = auth()->user()->jobPosts()->latest()->paginate(5);
        return view('employer.dashboard', compact('jobs'));
    }

    public function profile()
    {
        return view('employer.profile');
    }

    public function updateProfile(Request $request)
    {
        $user = auth()->user();
        
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'phone' => 'nullable|string|max:20',
            'about' => 'nullable|string',
            'company_name' => 'required|string|max:255',
        ]);
        
        $user->update($validated);
        
        return redirect()->back()->with('success', 'Profile updated successfully');
    }
}