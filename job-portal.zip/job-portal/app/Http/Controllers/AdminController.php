<?php

namespace App\Http\Controllers;

use App\Models\JobPost;
use App\Models\User;
use Illuminate\Http\Request;

class AdminController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
        $this->middleware('role:Admin');
    }

    public function dashboard()
    {
        $employersCount = User::whereHas('roles', function($query) {
            $query->where('name', 'Employer');
        })->count();
        
        $candidatesCount = User::whereHas('roles', function($query) {
            $query->where('name', 'Candidate');
        })->count();
        
        $jobPostsCount = JobPost::count();
        $pendingApprovalCount = JobPost::where('is_approved', false)->count();
        
        return view('admin.dashboard', compact(
            'employersCount', 
            'candidatesCount', 
            'jobPostsCount', 
            'pendingApprovalCount'
        ));
    }

    public function jobsForApproval()
    {
        $jobs = JobPost::where('is_approved', false)->paginate(10);
        return view('admin.jobs-approval', compact('jobs'));
    }

    public function approveJob($id)
    {
        $job = JobPost::findOrFail($id);
        $job->is_approved = true;
        $job->save();
        
        return redirect()->back()->with('success', 'Job approved successfully');
    }
}