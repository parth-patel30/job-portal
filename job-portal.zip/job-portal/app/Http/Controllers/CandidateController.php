<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class CandidateController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
        $this->middleware('role:Candidate');
    }

    public function dashboard()
    {
        $applications = auth()->user()->jobApplications()->with('jobPost')->latest()->paginate(10);
        return view('candidate.dashboard', compact('applications'));
    }

    public function profile()
    {
        return view('candidate.profile');
    }

    public function updateProfile(Request $request)
    {
        $user = auth()->user();
        
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'phone' => 'nullable|string|max:20',
            'about' => 'nullable|string',
        ]);
        
        if ($request->hasFile('resume')) {
            $request->validate([
                'resume' => 'file|mimes:pdf,doc,docx|max:2048',
            ]);
            
            // Delete old resume if exists
            if ($user->resume) {
                Storage::delete('public/resumes/' . $user->resume);
            }
            
            $resumeName = time() . '.' . $request->resume->extension();
            $request->resume->storeAs('public/resumes', $resumeName);
            $validated['resume'] = $resumeName;
        }
        
        $user->update($validated);
        
        return redirect()->back()->with('success', 'Profile updated successfully');
    }
}