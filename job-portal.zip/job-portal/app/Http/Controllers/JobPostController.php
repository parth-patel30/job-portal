<?php

namespace App\Http\Controllers;

use App\Models\JobPost;
use Illuminate\Http\Request;

class JobPostController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth')->except(['index', 'show']);
        $this->middleware('role:Employer')->except(['index', 'show']);
    }

    public function index()
    {
        $jobs = JobPost::where('is_active', true)
                      ->where('is_approved', true)
                      ->latest()
                      ->paginate(10);
        
        return view('jobs.index', compact('jobs'));
    }

    public function create()
    {
        return view('jobs.create');
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'title' => 'required|string|max:255',
            'description' => 'required|string',
            'location' => 'required|string|max:255',
            'type' => 'required|in:Full-time,Part-time,Contract',
            'salary' => 'nullable|numeric',
        ]);
        
        $job = auth()->user()->jobPosts()->create($validated);
        
        return redirect()->route('employer.dashboard')->with('success', 'Job posted successfully and awaiting approval');
    }

    public function show($id)
    {
        $job = JobPost::where('is_active', true)
                     ->where('is_approved', true)
                     ->findOrFail($id);
        
        return view('jobs.show', compact('job'));
    }

    public function edit($id)
    {
        $job = auth()->user()->jobPosts()->findOrFail($id);
        return view('jobs.edit', compact('job'));
    }

    public function update(Request $request, $id)
    {
        $job = auth()->user()->jobPosts()->findOrFail($id);
        
        $validated = $request->validate([
            'title' => 'required|string|max:255',
            'description' => 'required|string',
            'location' => 'required|string|max:255',
            'type' => 'required|in:Full-time,Part-time,Contract',
            'salary' => 'nullable|numeric',
            'is_active' => 'sometimes|boolean',
        ]);
        
        $job->update($validated);
        
        return redirect()->route('employer.dashboard')->with('success', 'Job updated successfully');
    }

    public function destroy($id)
    {
        $job = auth()->user()->jobPosts()->findOrFail($id);
        $job->delete();
        
        return redirect()->route('employer.dashboard')->with('success', 'Job deleted successfully');
    }
}